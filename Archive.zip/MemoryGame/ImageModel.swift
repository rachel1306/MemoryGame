//
//  ImageModel.swift
//  MemoryGame
//
//  Created by Maria Rachel Joseph on 24/04/23.
//

import Foundation

struct ImageModel: Codable{
    let items: [Item]
}

struct Item: Codable{
    let media: Media
}

struct Media: Codable{
    let m: String
}
