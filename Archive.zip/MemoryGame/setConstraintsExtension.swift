//
//  setConstraintsExtension.swift
//  MemoryGame
//
//  Created by Maria Rachel Joseph on 21/04/23.
//

import Foundation
import UIKit

extension UIView {
    func setConstrains(currentView: UIView){
        currentView.translatesAutoresizingMaskIntoConstraints = false
        currentView.topAnchor.constraint(equalTo: currentView.safeAreaLayoutGuide.topAnchor).isActive = true
        currentView.bottomAnchor.constraint(equalTo: currentView.safeAreaLayoutGuide.bottomAnchor).isActive = true
        currentView.leadingAnchor.constraint(equalTo: currentView.safeAreaLayoutGuide.leadingAnchor).isActive = true
        currentView.trailingAnchor.constraint(equalTo: currentView.safeAreaLayoutGuide.trailingAnchor).isActive = true
    }
}
