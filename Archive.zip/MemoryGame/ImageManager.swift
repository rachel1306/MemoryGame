//
//  ImageManager.swift
//  MemoryGame
//
//  Created by Maria Rachel Joseph on 24/04/23.
//

import Foundation
protocol ImageManagerDelegate{
    func didUpdateImages(images: ImageModel)
    func didFailWithErrors(error: Error)
}
class ImageManager{
    let imageURL = "https://api.flickr.com/services/feeds/photos_public.gne?format=json&lang=en-us&nojsoncallback=1&safe_search=1&tags=flowers"
    var delegate: ImageManagerDelegate?
    
    init(){
        performRequest()
    }
    
    func performRequest(){
        if let url = URL(string: imageURL){
            let session = URLSession(configuration: .default)
            let task = session.dataTask(with: url, completionHandler: handler(data:response:error:))
            task.resume()
        }
    }
    
    func handler(data: Data?, response: URLResponse?, error: Error?){
        if(error != nil){
            self.delegate?.didFailWithErrors(error: error! )
            return
        }
        if let safeData=data{
//            let dateString = String(data: safeData, encoding: .utf8)
//            print("\(dateString!) in handler")
            if let img = self.parseJSON(imageData: safeData){
                self.delegate?.didUpdateImages(images: img)
            }
        }
        
    }
    
    func parseJSON(imageData: Data) -> ImageModel?{
        let decoder = JSONDecoder()
        do{
            let decodedData = try decoder.decode(ImageModel.self, from: imageData)
//            let link = decodedData.items[0].link
            return decodedData
        }
        catch{
            delegate?.didFailWithErrors(error: error)
            return nil
        }
    }
}
