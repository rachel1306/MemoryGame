//
//  ImageManagerData.swift
//  MemoryGame
//
//  Created by Maria Rachel Joseph on 24/04/23.
//

import Foundation

struct ImageManagerData: Codable{
    let items: [Item]
}

struct Item: Codable{
    let link: String
}
