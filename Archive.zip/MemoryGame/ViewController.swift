//
//  ViewController.swift
//  MemoryGame
//
//  Created by Maria Rachel Joseph on 20/04/23.
//

import UIKit

class ViewController: UIViewController, ImageManagerDelegate {

    var allImages: [String] = []
    var shuffledImages: [String] = []
    var copyShuffled: [String] = []
    var randomImage: String = ""
    var isGameOver: Bool = true
    var scores = 0, attempts = 0
    @IBOutlet weak var mainView: UIView!
    @IBOutlet weak var mainImage: UIImageView!
    var colletionView: UICollectionView!
    
    @IBOutlet weak var timerLabel: UINavigationItem!
    var counter = 15
    var timer = Timer()
    
    var mainImageURL: String = ""
    var imageManager = ImageManager()
    var itemURL: [String] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        imageManager.delegate = self
        startGame()
        configureNav()
        congifureCollectionView()
    }
    
    private func configureNav(){
        let refreshButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonItem.SystemItem.refresh, target: self, action: #selector(onRefresh))
        navigationItem.leftBarButtonItem = refreshButton
    }
    
    func startGame(){
        timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(updateCounter), userInfo: nil, repeats: true)
        findImages(img: allImages)
    }
    @objc func updateCounter(){
        if counter > 0 {
            timerLabel.title = "00:\(String(counter))"
                counter -= 1
        }
        else{
            timerLabel.title = "Score: 0/0"
            timer.invalidate()
            configureTopImage()
            isGameOver = false
            if let visiblecells = colletionView.visibleCells as? [ImageCollectionViewCell] {
                for cell in visiblecells {
                    cell.contentView.backgroundColor = .darkGray
                    cell.imageView.isHidden = true
                }
            }
        }
    }
    
    func findImages(img: [String]){
        shuffledImages = Array(img.shuffled().prefix(9))
        copyShuffled = shuffledImages
    }
    
    private func configureTopImage(){
        if !shuffledImages.isEmpty{
            randomImage = shuffledImages.randomElement()!
            mainImageURL = randomImage
            mainImage.load(url: URL(string: randomImage)!)
        }
    }
    
        private func congifureCollectionView(){
            let layout = UICollectionViewFlowLayout()
            layout.itemSize = CGSize(width: 400, height: 400)
            colletionView = UICollectionView(frame: .zero, collectionViewLayout: layout)
            mainView.addSubview(colletionView)
    //        mainImage.setConstrains(currentView: view)
            
            colletionView.translatesAutoresizingMaskIntoConstraints = false
    //        colletionView.topAnchor.constraint(equalTo: mainImage.bottomAnchor, constant: 20).isActive = true
            colletionView.bottomAnchor.constraint(equalTo: mainView.safeAreaLayoutGuide.bottomAnchor, constant: -10).isActive = true
            colletionView.leadingAnchor.constraint(equalTo: mainView.leadingAnchor, constant: 10).isActive = true
            colletionView.trailingAnchor.constraint(equalTo: mainView.trailingAnchor, constant: -10).isActive = true
          //  colletionView.widthAnchor.constraint(equalTo: mainView.widthAnchor, multiplier: 1).isActive =  true
            colletionView.heightAnchor.constraint(equalTo: mainView.widthAnchor, multiplier: 1).isActive = true
            
            colletionView.delegate = self
            colletionView.dataSource = self
            colletionView.backgroundColor = .white
            colletionView.register(ImageCollectionViewCell.self, forCellWithReuseIdentifier: "cell")
            
        }

    @objc func onRefresh(){
        scores = 0
        attempts = 0
        counter = 15
        timerLabel.title = "00:15"
        timerLabel.prompt = "Memorise the images"
        mainImage.image = UIImage(systemName: "")
        mainImageURL = ""
        if let visiblecells = colletionView.visibleCells as? [ImageCollectionViewCell] {
            for cell in visiblecells {
                cell.imageView.isHidden = false
                cell.contentView.backgroundColor = .clear
            }
        }
        ImageManager()
        colletionView.reloadData()
        startGame()
    }
    func didUpdateImages(images: ImageModel){
        DispatchQueue.main.async {
            for i in images.items{
                self.allImages.append(i.media.m)
            }
            self.timer.invalidate()
            self.startGame()
            self.colletionView.reloadData()
        }
    }
    func didFailWithErrors(error: Error){
        print(error)
    }
}


extension ViewController: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return shuffledImages.count
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let yourWidth = (collectionView.bounds.width-20)/3.0
        let yourHeight = collectionView.bounds.width/3

        return CGSize(width: yourWidth, height: yourHeight)
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! ImageCollectionViewCell
        cell.setImage(img: shuffledImages[indexPath.row])
        return cell
     }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if !isGameOver{
            attempts+=1
            let cell = collectionView.cellForItem(at: indexPath) as? ImageCollectionViewCell
            if mainImageURL == copyShuffled[indexPath.row]{
                cell?.imageView.isHidden = false
                cell?.contentView.backgroundColor = .clear
                shuffledImages.remove(at: shuffledImages.firstIndex(of: randomImage)!)
                configureTopImage()
                scores+=1
            }
            timerLabel.title = "Score: \(scores)/\(attempts)"
        }
        if scores == 9{
            timerLabel.title = "Game Over"
            timerLabel.prompt = "Score: \(scores)/\(attempts)"
            isGameOver = true
        }
    }
    
}

extension UIImageView {
    func load(url: URL) {
        DispatchQueue.global().async { [weak self] in
            if let data = try? Data(contentsOf: url) {
                if let image = UIImage(data: data) {
                    DispatchQueue.main.async {
                        self?.image = image
                    }
                }
            }
        }
    }
}
